# SeedlingSegmentation > train-yolov8
https://universe.roboflow.com/rmedu-bezmx/seedlingsegmentation

Provided by a Roboflow user
License: CC BY 4.0

