# SeedlingSegmentation > yolov8_v2
https://universe.roboflow.com/rmedu-bezmx/seedlingsegmentation

Provided by a Roboflow user
License: CC BY 4.0

